/*Header js start*/
const burgerMenu = document.getElementById("burger");
const navbarMenu = document.getElementById("menu");

burgerMenu.addEventListener("click", () => {
    burgerMenu.classList.toggle("active");
    navbarMenu.classList.toggle("active");

    if (navbarMenu.classList.contains("active")) {
        navbarMenu.style.maxHeight = navbarMenu.scrollHeight + "px";
    } else {
        navbarMenu.removeAttribute("style");
    }
});

/*Header js end*/

/*Header sticky on scroll js start */

$(window).scroll(function(){
      if ($(this).scrollTop() > 120) {
          $('.navbar').addClass('fixed');
      } else {
          $('.navbar').removeClass('fixed');
      }
});
/*Header sticky on scroll js end */

/* Featured section js start */

   $('.multiple-item').slick({
      infinite: true,
      slidesToShow: 4, 
      slidesToScroll: 1,
      arrows: false,
      dots: true,
      autoplay: true,
      responsive: [
	    {
	      breakpoint: 1025,
	      settings: {
	        slidesToShow: 3,
	        slidesToScroll: 1,
	        infinite: true,	        
	        arrows:false
	      }
	    },
	    {
	      breakpoint: 769,
	      settings: {
	        slidesToShow: 2,
	        slidesToScroll: 1,
	        infinite: true,	        
	        arrows:false
	      }
	    },
	    {
	      breakpoint: 480,
	      settings: {
	        slidesToShow: 1,
	        slidesToScroll: 1
	      }
	    }    
	  ] 
  });

/* Featured section js end */

/* Event section js start */
 $('.event-item').slick({
      infinite: true,
      slidesToShow: 2, 
      slidesToScroll: 1,
      arrows: false,
      autoplay: true,
      dots: true,
      responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }    
  ]
  });
/* Event section js end */

/* Countries section js start */
$('.countries-item').slick({
      infinite: true,
      slidesToShow: 3, 
      slidesToScroll: 1,
      arrows: false,
      autoplay: true,
      dots: true,
      responsive: [
    {
      breakpoint: 1025,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: true,
        dots: false,
        arrows:false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }    
  ]
  });
/* Countries section js end */

/* Testimonial section js start */
$('.center-item-slider').slick({ 
    autoplay: true,
    autoplaySpeed: 4000,
    slidesToShow: 2.5,
    arrows: false,
    dots: true,
    responsive: [
      {
        breakpoint: 992,
        settings: {
          arrows: false,          
          slidesToShow: 2.5
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,          
          slidesToShow: 1
        }
      }
    ]
  });
/* Testimonial section js end */

/* Animation js start */
AOS.init({
  duration: 1200,
})
/* Animation js end */